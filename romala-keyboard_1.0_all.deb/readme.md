# Romala

Keyboard layout for Romance languages
This layout extends the English keyboard with dead keys and accents
for writing in Spanish, Portuguese, French, Italian, and other Romance languages.

## Build deb package

```sh
dpkg-deb --build . .
```
